# ProGuard rules for Arrange
