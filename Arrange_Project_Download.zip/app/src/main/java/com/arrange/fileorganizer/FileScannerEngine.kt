package com.arrange.fileorganizer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object FileScannerEngine {

    private val rootDir: File
        get() = Environment.getExternalStorageDirectory()

    val safeTrashDir: File
        get() = File(rootDir, "Arrange_SafeTrash").apply { if (!exists()) mkdirs() }

    private val excludedDirNames = setOf(
        "Android",
        "Arrange_SafeTrash",
        ".thumbnails",
        ".Trash",
        ".trash"
    )

    private fun shouldSkipDir(dir: File): Boolean {
        val name = dir.name
        if (name.startsWith(".")) return true
        if (name in excludedDirNames) return true
        return false
    }

    private fun collectFiles(
        startDir: File,
        imagesOnly: Boolean = false,
        onProgress: (String) -> Unit
    ): List<File> {
        val result = mutableListOf<File>()
        val stack = ArrayDeque<File>()
        if (startDir.exists() && startDir.isDirectory) {
            stack.add(startDir)
        }
        var scannedCount = 0
        while (stack.isNotEmpty()) {
            val current = stack.removeLast()
            val children = current.listFiles() ?: continue
            for (child in children) {
                if (child.isDirectory) {
                    if (!shouldSkipDir(child)) {
                        stack.add(child)
                    }
                } else if (child.isFile && child.length() > 0L) {
                    if (!imagesOnly || isImageFile(child)) {
                        result.add(child)
                    }
                    scannedCount++
                    if (scannedCount % 200 == 0) {
                        onProgress("تم فحص $scannedCount ملف...")
                    }
                }
            }
        }
        return result
    }

    private fun getImageDimensions(file: File): Pair<Int, Int> {
        if (!isImageFile(file)) return 0 to 0
        return try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, opts)
            opts.outWidth.coerceAtLeast(0) to opts.outHeight.coerceAtLeast(0)
        } catch (_: Exception) {
            0 to 0
        }
    }

    private fun toFileItem(file: File): FileItem {
        val (w, h) = getImageDimensions(file)
        return FileItem(file = file, width = w, height = h)
    }

    private fun computeSha256(file: File): String? {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            FileInputStream(file).use { fis ->
                val buffer = ByteArray(8192)
                var read: Int
                while (fis.read(buffer).also { read = it } != -1) {
                    digest.update(buffer, 0, read)
                }
            }
            digest.digest().joinToString("") { "%02x".format(it) }
        } catch (_: Exception) {
            null
        }
    }

    private fun chooseBestFile(items: List<FileItem>): String {
        return items.maxWithOrNull(
            compareBy<FileItem> { it.pixelCount }
                .thenBy { it.sizeBytes }
                .thenBy {
                    val p = it.path.lowercase()
                    when {
                        p.contains("/dcim/") || p.contains("/camera/") -> 3
                        p.contains("/pictures/") -> 2
                        else -> 1
                    }
                }
                .thenBy { -it.lastModified }
        )?.path ?: items.first().path
    }

    // 1. Exact Duplicates (Size grouping -> SHA-256)
    suspend fun findExactDuplicates(
        targetDir: File = rootDir,
        onProgress: (String) -> Unit
    ): List<FileGroup> = withContext(Dispatchers.IO) {
        onProgress("جاري تجميع الملفات...")
        val allFiles = collectFiles(targetDir, imagesOnly = false, onProgress = onProgress)
        val bySize = allFiles.groupBy { it.length() }.filter { it.value.size > 1 }

        val groups = mutableListOf<FileGroup>()
        var processed = 0
        val totalCandidates = bySize.values.sumOf { it.size }

        for ((_, sameSizeFiles) in bySize) {
            val hashMap = mutableMapOf<String, MutableList<File>>()
            for (f in sameSizeFiles) {
                processed++
                if (processed % 25 == 0) {
                    onProgress("مقارنة البصمة الرقمية ($processed / $totalCandidates)...")
                }
                val hash = computeSha256(f) ?: continue
                hashMap.getOrPut(hash) { mutableListOf() }.add(f)
            }
            for ((hash, dupFiles) in hashMap) {
                if (dupFiles.size > 1) {
                    val items = dupFiles.map { toFileItem(it) }
                    val best = chooseBestFile(items)
                    groups.add(
                        FileGroup(
                            id = hash,
                            title = "تطابق تام (${items.size} نسخ)",
                            files = items.sortedByDescending { it.path == best },
                            bestFilePath = best,
                            similarityPercent = 100
                        )
                    )
                }
            }
        }
        groups.sortedByDescending { it.files.first().sizeBytes * (it.files.size - 1) }
    }

    // 2. Similar Photos (64-bit dHash + Hamming distance <= 8)
    private fun computeDHash(file: File): Long? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            var sample = 1
            while (bounds.outWidth / sample > 128 && bounds.outHeight / sample > 128) {
                sample *= 2
            }

            val decodeOpts = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.RGB_565
            }
            val bitmap = BitmapFactory.decodeFile(file.absolutePath, decodeOpts) ?: return null
            val scaled = Bitmap.createScaledBitmap(bitmap, 9, 8, true)
            if (scaled != bitmap) bitmap.recycle()

            var hash = 0L
            var bit = 0
            for (y in 0 until 8) {
                for (x in 0 until 8) {
                    val pLeft = scaled.getPixel(x, y)
                    val pRight = scaled.getPixel(x + 1, y)
                    val lGray = (((pLeft shr 16) and 0xFF) * 30 + ((pLeft shr 8) and 0xFF) * 59 + (pLeft and 0xFF) * 11)
                    val rGray = (((pRight shr 16) and 0xFF) * 30 + ((pRight shr 8) and 0xFF) * 59 + (pRight and 0xFF) * 11)
                    if (lGray > rGray) {
                        hash = hash or (1L shl bit)
                    }
                    bit++
                }
            }
            scaled.recycle()
            hash
        } catch (_: Exception) {
            null
        }
    }

    suspend fun findSimilarPhotos(
        targetDir: File = rootDir,
        maxHammingDistance: Int = 8,
        onProgress: (String) -> Unit
    ): List<FileGroup> = withContext(Dispatchers.IO) {
        onProgress("جاري البحث عن الصور...")
        val imageFiles = collectFiles(targetDir, imagesOnly = true, onProgress = onProgress)
        val hashed = mutableListOf<Pair<FileItem, Long>>()

        imageFiles.forEachIndexed { idx, file ->
            if (idx % 30 == 0) {
                onProgress("تحليل بصمة الصور (${idx + 1} / ${imageFiles.size})...")
            }
            val dHash = computeDHash(file)
            if (dHash != null) {
                hashed.add(toFileItem(file) to dHash)
            }
        }

        val n = hashed.size
        if (n < 2) return@withContext emptyList()

        onProgress("جاري مقارنة التشابه البصري بين $n صورة...")
        val parent = IntArray(n) { it }
        fun find(x: Int): Int {
            var r = x
            while (parent[r] != r) {
                parent[r] = parent[parent[r]]
                r = parent[r]
            }
            return r
        }
        fun union(a: Int, b: Int) {
            val ra = find(a)
            val rb = find(b)
            if (ra != rb) parent[ra] = rb
        }

        val minDistances = IntArray(n) { 64 }
        for (i in 0 until n) {
            val h1 = hashed[i].second
            for (j in i + 1 until n) {
                val dist = java.lang.Long.bitCount(h1 xor hashed[j].second)
                if (dist <= maxHammingDistance) {
                    union(i, j)
                    if (dist < minDistances[i]) minDistances[i] = dist
                    if (dist < minDistances[j]) minDistances[j] = dist
                }
            }
        }

        val clusters = mutableMapOf<Int, MutableList<Int>>()
        for (i in 0 until n) {
            clusters.getOrPut(find(i)) { mutableListOf() }.add(i)
        }

        val groups = mutableListOf<FileGroup>()
        var groupIndex = 1
        for ((_, indices) in clusters) {
            if (indices.size > 1) {
                val items = indices.map { hashed[it].first }
                val best = chooseBestFile(items)
                val avgDist = indices.map { minDistances[it] }.average().toInt().coerceIn(0, 64)
                val similarity = (((64 - avgDist) * 100) / 64).coerceIn(75, 100)
                groups.add(
                    FileGroup(
                        id = "sim_$groupIndex",
                        title = "صور متشابهة (${items.size} صور • تشابه $similarity%)",
                        files = items.sortedWith(
                            compareByDescending<FileItem> { it.path == best }
                                .thenByDescending { it.pixelCount }
                                .thenByDescending { it.sizeBytes }
                        ),
                        bestFilePath = best,
                        similarityPercent = similarity
                    )
                )
                groupIndex++
            }
        }

        groups.sortedByDescending { it.files.size }
    }

    // 3. Auto-Organizer
    fun getCommonMessyFolders(): List<Pair<String, File>> {
        val candidates = listOf(
            "التنزيلات (Download)" to File(rootDir, "Download"),
            "صور واتساب (WhatsApp Images)" to File(rootDir, "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images"),
            "مستندات واتساب (WhatsApp Docs)" to File(rootDir, "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Documents"),
            "واتساب قديم (WhatsApp/Media)" to File(rootDir, "WhatsApp/Media/WhatsApp Images"),
            "لقطات الشاشة (Screenshots)" to File(rootDir, "DCIM/Screenshots"),
            "الصور (Pictures)" to File(rootDir, "Pictures"),
            "المستندات (Documents)" to File(rootDir, "Documents")
        )
        return candidates.filter { it.second.exists() && it.second.isDirectory }
    }

    private fun categoryForExtension(ext: String): String {
        return when (ext.lowercase()) {
            "jpg", "jpeg", "png", "webp", "gif", "bmp", "heic" -> "صور"
            "mp4", "mkv", "avi", "mov", "3gp", "webm" -> "فيديوهات"
            "pdf" -> "مستندات_PDF"
            "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt" -> "مستندات_أخرى"
            "mp3", "wav", "m4a", "ogg", "opus", "aac" -> "صوتيات"
            "apk", "xapk" -> "تطبيقات_APK"
            "zip", "rar", "7z", "tar", "gz" -> "ملفات_مضغوطة"
            else -> "ملفات_متنوعة"
        }
    }

    suspend fun organizeFolder(
        folder: File,
        mode: OrganizeMode,
        onProgress: (String) -> Unit
    ): Int = withContext(Dispatchers.IO) {
        val files = folder.listFiles()?.filter { it.isFile && !it.name.startsWith(".") } ?: return@withContext 0
        val dateFormat = SimpleDateFormat("yyyy-MM", Locale.US)
        var movedCount = 0

        files.forEachIndexed { index, file ->
            onProgress("تنظيم الملف ${index + 1} من ${files.size}...")
            val targetSubfolderName = when (mode) {
                OrganizeMode.BY_TYPE -> categoryForExtension(file.extension)
                OrganizeMode.BY_DATE -> dateFormat.format(Date(file.lastModified()))
            }
            val destDir = File(folder, targetSubfolderName).apply { if (!exists()) mkdirs() }
            val destFile = resolveUniqueDestination(destDir, file.name)
            if (safeMoveFile(file, destFile)) {
                movedCount++
            }
        }
        movedCount
    }

    // 4. Space Hunter
    suspend fun scanSpaceWasters(
        largeThresholdMb: Int = 50,
        onProgress: (String) -> Unit
    ): SpaceReport = withContext(Dispatchers.IO) {
        onProgress("جاري فحص الملفات الكبيرة والتطبيقات...")
        val allFiles = collectFiles(rootDir, imagesOnly = false, onProgress = onProgress)
        val thresholdBytes = largeThresholdMb.toLong() * 1024L * 1024L

        val largeFiles = allFiles
            .filter { it.length() >= thresholdBytes }
            .sortedByDescending { it.length() }
            .map { toFileItem(it) }

        val apkFiles = allFiles
            .filter { it.extension.equals("apk", ignoreCase = true) }
            .sortedByDescending { it.length() }
            .map { toFileItem(it) }

        onProgress("جاري البحث عن المجلدات الفارغة...")
        val emptyFolders = mutableListOf<File>()
        fun findEmpty(dir: File): Boolean {
            if (shouldSkipDir(dir)) return false
            val children = dir.listFiles() ?: return false
            if (children.isEmpty()) {
                if (dir != rootDir) emptyFolders.add(dir)
                return true
            }
            var allChildrenEmptyDirs = true
            for (child in children) {
                if (child.isDirectory) {
                    if (!findEmpty(child)) allChildrenEmptyDirs = false
                } else {
                    allChildrenEmptyDirs = false
                }
            }
            if (allChildrenEmptyDirs && dir != rootDir) {
                emptyFolders.add(dir)
                return true
            }
            return false
        }
        findEmpty(rootDir)

        SpaceReport(largeFiles = largeFiles, apkFiles = apkFiles, emptyFolders = emptyFolders)
    }

    // 5. Safety Layer (Safe Trash & Delete)
    fun resolveUniqueDestination(destDir: File, fileName: String): File {
        var candidate = File(destDir, fileName)
        if (!candidate.exists()) return candidate
        val dot = fileName.lastIndexOf('.')
        val base = if (dot > 0) fileName.substring(0, dot) else fileName
        val ext = if (dot > 0) fileName.substring(dot) else ""
        var counter = 1
        while (candidate.exists()) {
            candidate = File(destDir, "${base}_($counter)$ext")
            counter++
        }
        return candidate
    }

    fun safeMoveFile(source: File, dest: File): Boolean {
        if (source.renameTo(dest)) return true
        return try {
            source.copyTo(dest, overwrite = false)
            source.delete()
        } catch (_: Exception) {
            false
        }
    }

    suspend fun moveToSafeTrash(files: List<File>): Int = withContext(Dispatchers.IO) {
        val trash = safeTrashDir
        var moved = 0
        for (f in files) {
            if (f.exists()) {
                val dest = resolveUniqueDestination(trash, f.name)
                if (safeMoveFile(f, dest)) moved++
            }
        }
        moved
    }

    suspend fun deletePermanently(files: List<File>): Int = withContext(Dispatchers.IO) {
        var deleted = 0
        for (f in files) {
            if (f.exists() && f.delete()) deleted++
        }
        deleted
    }

    suspend fun getSafeTrashFiles(): List<FileItem> = withContext(Dispatchers.IO) {
        val trash = safeTrashDir
        trash.listFiles()
            ?.filter { it.isFile }
            ?.sortedByDescending { it.lastModified() }
            ?.map { toFileItem(it) }
            ?: emptyList()
    }
}
