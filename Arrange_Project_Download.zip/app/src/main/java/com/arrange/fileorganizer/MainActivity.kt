@file:OptIn(ExperimentalMaterial3Api::class)

package com.arrange.fileorganizer

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFF1565C0),
                    secondary = Color(0xFF00897B)
                )
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    ArrangeApp()
                }
            }
        }
    }
}

private fun hasAllFilesPermission(): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Environment.isExternalStorageManager()
    } else {
        true
    }
}

@Composable
fun ArrangeApp() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var permissionGranted by remember { mutableStateOf(hasAllFilesPermission()) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                permissionGranted = hasAllFilesPermission()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    if (!permissionGranted) {
        PermissionScreen(
            onRequestPermission = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                        data = Uri.parse("package:${context.packageName}")
                    }
                    context.startActivity(intent)
                }
            }
        )
    } else {
        MainWorkspace()
    }
}

@Composable
fun PermissionScreen(onRequestPermission: () -> Unit) {
    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(28.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                Icons.Default.FolderOpen,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(80.dp)
            )
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "مرحباً بك في Arrange",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "لكي يتمكن التطبيق من فحص الصور المتشابهة والملفات المكررة وتنظيم مجلداتك بأمان، يحتاج إلى صلاحية الوصول للملفات (All Files Access).",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(24.dp))
            Button(
                onClick = onRequestPermission,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("منح صلاحية الوصول للملفات", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun MainWorkspace() {
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var currentTab by remember { mutableIntStateOf(0) }
    var isScanning by remember { mutableStateOf(false) }
    var progressMessage by remember { mutableStateOf("") }

    // Data states
    var duplicateGroups by remember { mutableStateOf<List<FileGroup>>(emptyList()) }
    var similarGroups by remember { mutableStateOf<List<FileGroup>>(emptyList()) }
    var spaceReport by remember { mutableStateOf<SpaceReport?>(null) }

    // Selection & preview states
    var selectedPaths by remember { mutableStateOf<Set<String>>(emptySet()) }
    var previewItem by remember { mutableStateOf<FileItem?>(null) }
    var showConfirmDelete by remember { mutableStateOf(false) }
    var showSafeTrash by remember { mutableStateOf(false) }
    var trashFiles by remember { mutableStateOf<List<FileItem>>(emptyList()) }

    fun togglePath(path: String) {
        selectedPaths = if (path in selectedPaths) selectedPaths - path else selectedPaths + path
    }

    fun allKnownFileItems(): Map<String, FileItem> {
        val map = mutableMapOf<String, FileItem>()
        duplicateGroups.forEach { g -> g.files.forEach { map[it.path] = it } }
        similarGroups.forEach { g -> g.files.forEach { map[it.path] = it } }
        spaceReport?.largeFiles?.forEach { map[it.path] = it }
        spaceReport?.apkFiles?.forEach { map[it.path] = it }
        return map
    }

    fun pruneRemovedPaths(removed: Set<String>) {
        duplicateGroups = duplicateGroups.mapNotNull { g ->
            val remaining = g.files.filter { it.path !in removed }
            if (remaining.size > 1) g.copy(files = remaining) else null
        }
        similarGroups = similarGroups.mapNotNull { g ->
            val remaining = g.files.filter { it.path !in removed }
            if (remaining.size > 1) g.copy(files = remaining) else null
        }
        spaceReport = spaceReport?.let { rep ->
            rep.copy(
                largeFiles = rep.largeFiles.filter { it.path !in removed },
                apkFiles = rep.apkFiles.filter { it.path !in removed }
            )
        }
        selectedPaths = selectedPaths - removed
    }

    val knownMap = allKnownFileItems()
    val selectedBytes = selectedPaths.sumOf { knownMap[it]?.sizeBytes ?: 0L }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("Arrange", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White
                ),
                actions = {
                    IconButton(onClick = {
                        scope.launch {
                            trashFiles = FileScannerEngine.getSafeTrashFiles()
                            showSafeTrash = true
                        }
                    }) {
                        Icon(Icons.Default.Shield, contentDescription = "سلة الأمان")
                    }
                }
            )
        },
        bottomBar = {
            Column {
                if (selectedPaths.isNotEmpty()) {
                    SelectionActionBar(
                        selectedCount = selectedPaths.size,
                        selectedBytes = selectedBytes,
                        onMoveToSafeTrash = {
                            scope.launch {
                                val files = selectedPaths.map { File(it) }
                                val moved = FileScannerEngine.moveToSafeTrash(files)
                                pruneRemovedPaths(selectedPaths)
                                snackbarHostState.showSnackbar("تم نقل $moved ملف إلى سلة الأمان")
                            }
                        },
                        onDeletePermanently = { showConfirmDelete = true },
                        onClearSelection = { selectedPaths = emptySet() }
                    )
                }
                NavigationBar {
                    NavigationBarItem(
                        selected = currentTab == 0,
                        onClick = { currentTab = 0 },
                        icon = { Icon(Icons.Default.ContentCopy, contentDescription = null) },
                        label = { Text("المكرر") }
                    )
                    NavigationBarItem(
                        selected = currentTab == 1,
                        onClick = { currentTab = 1 },
                        icon = { Icon(Icons.Default.PhotoLibrary, contentDescription = null) },
                        label = { Text("المتشابهة") }
                    )
                    NavigationBarItem(
                        selected = currentTab == 2,
                        onClick = { currentTab = 2 },
                        icon = { Icon(Icons.Default.FolderCopy, contentDescription = null) },
                        label = { Text("التنظيم") }
                    )
                    NavigationBarItem(
                        selected = currentTab == 3,
                        onClick = { currentTab = 3 },
                        icon = { Icon(Icons.Default.Storage, contentDescription = null) },
                        label = { Text("المساحة") }
                    )
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (currentTab) {
                0 -> GroupsTabScreen(
                    headerTitle = "كاشف الملفات المكررة تماماً",
                    headerDesc = "يفحص الملفات بالبصمة الرقمية SHA-256 بدقة 100% حتى لو اختلفت أسماؤها.",
                    scanButtonText = "ابدأ فحص المكرر",
                    groups = duplicateGroups,
                    isScanning = isScanning,
                    progressMessage = progressMessage,
                    selectedPaths = selectedPaths,
                    onStartScan = {
                        scope.launch {
                            isScanning = true
                            selectedPaths = emptySet()
                            duplicateGroups = FileScannerEngine.findExactDuplicates { msg ->
                                progressMessage = msg
                            }
                            isScanning = false
                            snackbarHostState.showSnackbar("تم العثور على ${duplicateGroups.size} مجموعة مكررة")
                        }
                    },
                    onAutoSelectLowerQuality = {
                        val toSelect = duplicateGroups.flatMap { g ->
                            g.files.filter { it.path != g.bestFilePath }.map { it.path }
                        }.toSet()
                        selectedPaths = selectedPaths + toSelect
                    },
                    onToggleSelect = ::togglePath,
                    onPreviewImage = { previewItem = it }
                )

                1 -> GroupsTabScreen(
                    headerTitle = "كاشف الصور المتشابهة بصرياً",
                    headerDesc = "يلتقط اللقطات المتتالية ونسخ واتساب المضغوطة ويعرضها بحجم كبير مع تمييز النسخة الأعلى جودة.",
                    scanButtonText = "ابدأ فحص الصور المتشابهة",
                    groups = similarGroups,
                    isScanning = isScanning,
                    progressMessage = progressMessage,
                    selectedPaths = selectedPaths,
                    onStartScan = {
                        scope.launch {
                            isScanning = true
                            selectedPaths = emptySet()
                            similarGroups = FileScannerEngine.findSimilarPhotos { msg ->
                                progressMessage = msg
                            }
                            isScanning = false
                            snackbarHostState.showSnackbar("تم العثور على ${similarGroups.size} مجموعة صور متشابهة")
                        }
                    },
                    onAutoSelectLowerQuality = {
                        val toSelect = similarGroups.flatMap { g ->
                            g.files.filter { it.path != g.bestFilePath }.map { it.path }
                        }.toSet()
                        selectedPaths = selectedPaths + toSelect
                    },
                    onToggleSelect = ::togglePath,
                    onPreviewImage = { previewItem = it }
                )

                2 -> AutoOrganizerScreen(
                    isBusy = isScanning,
                    progressMessage = progressMessage,
                    onOrganize = { folder, mode ->
                        scope.launch {
                            isScanning = true
                            val moved = FileScannerEngine.organizeFolder(folder, mode) { msg ->
                                progressMessage = msg
                            }
                            isScanning = false
                            snackbarHostState.showSnackbar("تم تنظيم $moved ملف داخل ${folder.name} بنجاح")
                        }
                    }
                )

                3 -> SpaceHunterScreen(
                    report = spaceReport,
                    isScanning = isScanning,
                    progressMessage = progressMessage,
                    selectedPaths = selectedPaths,
                    onStartScan = {
                        scope.launch {
                            isScanning = true
                            spaceReport = FileScannerEngine.scanSpaceWasters { msg ->
                                progressMessage = msg
                            }
                            isScanning = false
                        }
                    },
                    onToggleSelect = ::togglePath,
                    onPreviewImage = { previewItem = it },
                    onDeleteEmptyFolders = { folders ->
                        scope.launch {
                            var deleted = 0
                            folders.forEach { if (it.exists() && it.delete()) deleted++ }
                            spaceReport = spaceReport?.copy(emptyFolders = emptyList())
                            snackbarHostState.showSnackbar("تم حذف $deleted مجلد فارغ")
                        }
                    }
                )
            }
        }
    }

    // Full-screen zoomable image viewer
    previewItem?.let { item ->
        FullScreenImageViewer(
            item = item,
            isSelected = item.path in selectedPaths,
            onToggleSelect = { togglePath(item.path) },
            onDismiss = { previewItem = null }
        )
    }

    // Permanent delete confirmation dialog
    if (showConfirmDelete) {
        AlertDialog(
            onDismissRequest = { showConfirmDelete = false },
            title = { Text("تأكيد الحذف النهائي") },
            text = {
                Text("هل أنت متأكد من حذف ${selectedPaths.size} ملف نهائياً (${formatFileSize(selectedBytes)})؟ لا يمكن التراجع عن هذه الخطوة.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmDelete = false
                        scope.launch {
                            val files = selectedPaths.map { File(it) }
                            val deleted = FileScannerEngine.deletePermanently(files)
                            pruneRemovedPaths(selectedPaths)
                            snackbarHostState.showSnackbar("تم حذف $deleted ملف نهائياً")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SelectRed)
                ) {
                    Text("حذف نهائي")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmDelete = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Safe Trash Dialog
    if (showSafeTrash) {
        SafeTrashDialog(
            trashFiles = trashFiles,
            onEmptyTrash = {
                showSafeTrash = false
                scope.launch {
                    val count = FileScannerEngine.deletePermanently(trashFiles.map { it.file })
                    trashFiles = emptyList()
                    snackbarHostState.showSnackbar("تم تفريغ سلة الأمان ($count ملف)")
                }
            },
            onDismiss = { showSafeTrash = false }
        )
    }
}

@Composable
fun GroupsTabScreen(
    headerTitle: String,
    headerDesc: String,
    scanButtonText: String,
    groups: List<FileGroup>,
    isScanning: Boolean,
    progressMessage: String,
    selectedPaths: Set<String>,
    onStartScan: () -> Unit,
    onAutoSelectLowerQuality: () -> Unit,
    onToggleSelect: (String) -> Unit,
    onPreviewImage: (FileItem) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(headerTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(headerDesc, style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onStartScan,
                        enabled = !isScanning,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Search, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(scanButtonText)
                    }
                    if (groups.isNotEmpty() && !isScanning) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = onAutoSelectLowerQuality,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.AutoFixHigh, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("تحديد النسخ الأقل جودة تلقائياً")
                        }
                    }
                }
            }
        }

        if (isScanning) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator()
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(progressMessage, style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else if (groups.isEmpty()) {
            item {
                Text(
                    text = "اضغط على زر الفحص بالأعلى للبدء. لن يتم حذف أي ملف إلا بعد مراجعتك وموافقتك.",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(groups, key = { it.id }) { group ->
                GroupCard(
                    group = group,
                    selectedPaths = selectedPaths,
                    onToggleSelect = onToggleSelect,
                    onPreviewImage = onPreviewImage
                )
            }
        }
    }
}

@Composable
fun AutoOrganizerScreen(
    isBusy: Boolean,
    progressMessage: String,
    onOrganize: (File, OrganizeMode) -> Unit
) {
    val folders = remember { FileScannerEngine.getCommonMessyFolders() }
    var selectedMode by remember { mutableStateOf(OrganizeMode.BY_TYPE) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("المنظّم التلقائي للمجلدات", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("اختر طريقة الفرز ثم اضغط على المجلد المطلوب ترتيبه:", style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OrganizeMode.entries.forEach { mode ->
                            FilterChip(
                                selected = selectedMode == mode,
                                onClick = { selectedMode = mode },
                                label = { Text(mode.label) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(selectedMode.description, style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        if (isBusy) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator()
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(progressMessage)
                }
            }
        } else {
            items(folders) { (label, dir) ->
                val directFilesCount = dir.listFiles()?.count { it.isFile && !it.name.startsWith(".") } ?: 0
                ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(label, fontWeight = FontWeight.Bold)
                            Text(
                                "$directFilesCount ملف غير مصنّف حالياً",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Button(
                            onClick = { onOrganize(dir, selectedMode) },
                            enabled = directFilesCount > 0
                        ) {
                            Text("ترتيب الآن")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SpaceHunterScreen(
    report: SpaceReport?,
    isScanning: Boolean,
    progressMessage: String,
    selectedPaths: Set<String>,
    onStartScan: () -> Unit,
    onToggleSelect: (String) -> Unit,
    onPreviewImage: (FileItem) -> Unit,
    onDeleteEmptyFolders: (List<File>) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("صائد المساحة المهدورة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("يكشف الملفات الأكبر من 50 ميجابايت، وملفات التثبيت APK القديمة، والمجلدات الفارغة.", style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onStartScan,
                        enabled = !isScanning,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.CleaningServices, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("فحص المساحة المهدورة")
                    }
                }
            }
        }

        if (isScanning) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator()
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(progressMessage)
                }
            }
        } else if (report != null) {
            if (report.emptyFolders.isNotEmpty()) {
                item {
                    ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("مجلدات فارغة", fontWeight = FontWeight.Bold)
                                Text("${report.emptyFolders.size} مجلد فارغ لا يحتوي على ملفات", style = MaterialTheme.typography.bodySmall)
                            }
                            Button(onClick = { onDeleteEmptyFolders(report.emptyFolders) }) {
                                Text("تنظيفها")
                            }
                        }
                    }
                }
            }

            if (report.apkFiles.isNotEmpty()) {
                item {
                    Text("ملفات التثبيت القديمة (${report.apkFiles.size} ملف APK)", fontWeight = FontWeight.Bold)
                }
                items(report.apkFiles, key = { it.path }) { item ->
                    LargeFilePreviewCard(
                        item = item,
                        isBest = false,
                        isSelected = item.path in selectedPaths,
                        onToggleSelect = { onToggleSelect(item.path) },
                        onPreviewImage = { onPreviewImage(item) }
                    )
                }
            }

            if (report.largeFiles.isNotEmpty()) {
                item {
                    Text("أكبر الملفات حجماً (${report.largeFiles.size} ملف)", fontWeight = FontWeight.Bold)
                }
                items(report.largeFiles, key = { it.path }) { item ->
                    LargeFilePreviewCard(
                        item = item,
                        isBest = false,
                        isSelected = item.path in selectedPaths,
                        onToggleSelect = { onToggleSelect(item.path) },
                        onPreviewImage = { onPreviewImage(item) }
                    )
                }
            }
        }
    }
}
