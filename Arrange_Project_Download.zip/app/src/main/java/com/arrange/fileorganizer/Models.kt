package com.arrange.fileorganizer

import java.io.File

data class FileItem(
    val file: File,
    val name: String = file.name,
    val path: String = file.absolutePath,
    val sizeBytes: Long = file.length(),
    val lastModified: Long = file.lastModified(),
    val folderDisplay: String = formatFolderDisplay(file),
    val isImage: Boolean = isImageFile(file),
    val width: Int = 0,
    val height: Int = 0
) {
    val resolutionText: String
        get() = if (width > 0 && height > 0) "${width} × ${height}" else ""

    val pixelCount: Long
        get() = width.toLong() * height.toLong()
}

data class FileGroup(
    val id: String,
    val title: String,
    val files: List<FileItem>,
    val bestFilePath: String,
    val similarityPercent: Int = 100
)

enum class OrganizeMode(val label: String, val description: String) {
    BY_TYPE("حسب النوع", "فرز تلقائي إلى: صور، فيديوهات، مستندات PDF، صوتيات، تطبيقات APK"),
    BY_DATE("حسب السنة والشهر", "فرز تلقائي في مجلدات مرتبة بالتاريخ مثل 2026-11")
}

data class SpaceReport(
    val largeFiles: List<FileItem> = emptyList(),
    val apkFiles: List<FileItem> = emptyList(),
    val emptyFolders: List<File> = emptyList()
)

fun isImageFile(file: File): Boolean {
    val ext = file.extension.lowercase()
    return ext in setOf("jpg", "jpeg", "png", "webp", "bmp", "heic")
}

fun formatFolderDisplay(file: File): String {
    val parent = file.parentFile?.absolutePath ?: return ""
    val cleaned = parent.removePrefix("/storage/emulated/0/")
        .removePrefix("/storage/emulated/0")
    return if (cleaned.isBlank()) "التخزين الداخلي" else cleaned
}

fun formatFileSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return String.format("%.1f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024) return String.format("%.2f MB", mb)
    val gb = mb / 1024.0
    return String.format("%.2f GB", gb)
}
